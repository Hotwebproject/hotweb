"""
this class is used to create dom function eg.

function sample_dom_function(){
    // bla bla bla
    // dom manipulation
}
"""
class DomFunction:
    def __init__(self,name="sample_dom_function"):
        pass
    def add_child(self,child):
        pass