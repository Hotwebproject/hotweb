"""
used to define data types for different sql dialects

collect data types of different dialects and paste here

"""

DataTypes = {
    "STRING":"STRING",
    "REAL":"REAL",
    "INT":"INT",
}