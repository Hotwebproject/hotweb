"""
like this model is called test,=====in the models folder of client app==============

from hotweb.models import Models

class model_init:
    pass

ModelName = Models("ModelName",db)
"""