from server import render

render()