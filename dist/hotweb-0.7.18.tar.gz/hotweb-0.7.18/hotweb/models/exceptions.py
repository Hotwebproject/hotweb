"""
compare model key value pairs
"""
class InvalidModelEntries(Exception):
    pass