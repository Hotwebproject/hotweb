"""
to define db queries for different sql dialect
"""