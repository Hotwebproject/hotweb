class WrongType(Exception):
    pass

class FunctionExpected(Exception):
    pass