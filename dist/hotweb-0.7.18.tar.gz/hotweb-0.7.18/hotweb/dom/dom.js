
        $(document).ready(function(){
        // d instance call

 	})