"""
compare model key value pairs
"""
class InvalidModelEntries(Exception):
    pass
class ErrorCreatingTable(Exception):
    pass
class ErrorDropingTable(Exception):
    pass